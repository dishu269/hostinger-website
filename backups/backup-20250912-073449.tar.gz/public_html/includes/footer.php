  </main>
  <footer class="site-footer">
    <div class="container">
      <p>© <?= date('Y') ?> <?= SITE_BRAND ?>. All rights reserved.</p>
    </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.2.0/dist/chart.umd.min.js" defer></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.29.2/feather.min.js" defer></script>
  <script src="/assets/js/main.js" defer></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      feather.replace();
    });
  </script>
</body>
</html>