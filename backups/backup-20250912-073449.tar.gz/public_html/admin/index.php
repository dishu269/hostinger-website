<?php
// Redirect to admin menu
header('Location: /admin/menu.php');
exit;
?>


